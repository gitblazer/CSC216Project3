package edu.ncsu.csc216.solitaire.model;

public class Test {
	public static void main(String[] args) {
		
	}
}