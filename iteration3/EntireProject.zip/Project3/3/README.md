#Project 3 For CSC 216
##Solitaire and Encryption
